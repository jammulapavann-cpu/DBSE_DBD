const http = require('http');
const fs = require('fs');
const path = require('path');
const { randomUUID } = require('crypto');

const ROOT = __dirname;
const APP_ROOT = path.resolve(ROOT, '.vscode', 'data', 'public');
const DATA_FILE = path.join(ROOT, 'data', 'app-data.json');
const PORT = process.env.PORT || 4173;

function readData() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function json(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 6_000_000) req.destroy();
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error('Invalid JSON body')); }
    });
    req.on('error', reject);
  });
}

function activeUser(data) {
  return data.users.find((user) => user.id === data.sessionUserId) || null;
}

function publicUser(user) {
  if (!user) return null;
  const { password, ...safeUser } = user;
  return safeUser;
}

function recipeForClient(recipe, user) {
  return {
    ...recipe,
    isSaved: Boolean(user?.savedRecipeIds?.includes(recipe.id)),
    userRating: user?.ratings?.[recipe.id] || null
  };
}

function normalizeIngredient(ingredient) {
  const amount = Number(ingredient.amount) || 0;
  return {
    name: String(ingredient.name || '').trim(),
    amount,
    unit: String(ingredient.unit || '').trim(),
    aisle: String(ingredient.aisle || 'Pantry').trim()
  };
}

function groceryItems(data, user) {
  const bucket = new Map();
  Object.values(data.mealPlans[user.id] || {}).forEach((recipeId) => {
    const recipe = data.recipes.find((item) => item.id === recipeId);
    recipe?.ingredients.forEach((ingredient) => {
      const key = `${ingredient.name.toLowerCase()}|${ingredient.unit.toLowerCase()}|${ingredient.aisle}`;
      const previous = bucket.get(key) || { ...ingredient, checked: false };
      previous.amount += bucket.has(key) ? Number(ingredient.amount || 0) : 0;
      bucket.set(key, previous);
    });
  });
  const checks = data.groceryChecks[user.id] || {};
  return [...bucket.entries()]
    .map(([key, item]) => ({ ...item, id: key, checked: Boolean(checks[key]) }))
    .sort((a, b) => a.aisle.localeCompare(b.aisle) || a.name.localeCompare(b.name));
}

function serveFile(res, pathname) {
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const candidates = [
    path.resolve(APP_ROOT, `.${safePath}`),
    path.resolve(ROOT, 'public', `.${safePath}`),
    path.resolve(ROOT, `.${safePath}`)
  ];
  const allowedRoots = [APP_ROOT, path.resolve(ROOT, 'public'), ROOT];
  const filePath = candidates.find((candidate) => allowedRoots.some((root) => candidate.startsWith(root) && fs.existsSync(candidate)));

  if (!filePath || !allowedRoots.some((root) => filePath.startsWith(root))) {
    return json(res, 403, { error: 'Forbidden' });
  }

  fs.readFile(filePath, (error, content) => {
    if (error) return json(res, 404, { error: 'Not found' });
    const extension = path.extname(filePath);
    const types = {
      '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
      '.js': 'application/javascript; charset=utf-8', '.svg': 'image/svg+xml'
    };
    res.writeHead(200, { 'Content-Type': types[extension] || 'application/octet-stream' });
    res.end(content);
  });
}

async function api(req, res, pathname) {
  const data = readData();
  const user = activeUser(data);
  const segments = pathname.split('/').filter(Boolean);
  const method = req.method;

  if (method === 'GET' && pathname === '/api/health') {
    return json(res, 200, { ok: true, name: 'Savorly' });
  }

  if (method === 'GET' && pathname === '/api/recipes') {
    return json(res, 200, {
      count: data.recipes.length,
      recipes: data.recipes.map((recipe) => recipeForClient(recipe, user))
    });
  }

  if (method === 'GET' && pathname === '/api/bootstrap') {
    return json(res, 200, {
      user: publicUser(user),
      recipes: data.recipes.map((recipe) => recipeForClient(recipe, user)),
      mealPlan: user ? data.mealPlans[user.id] || {} : {},
      grocery: user ? groceryItems(data, user) : []
    });
  }

  if (method === 'POST' && pathname === '/api/auth/login') {
    const body = await readBody(req);
    const email = String(body.email || '').trim().toLowerCase();
    const account = data.users.find((item) => item.email === email && item.password === body.password);
    if (!account) return json(res, 401, { error: 'Check your email and password.' });
    data.sessionUserId = account.id;
    writeData(data);
    return json(res, 200, { user: publicUser(account) });
  }

  if (method === 'POST' && pathname === '/api/auth/register') {
    const body = await readBody(req);
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    if (!name || !email || String(body.password || '').length < 4) {
      return json(res, 400, { error: 'Enter your name, email, and a password with at least 4 characters.' });
    }
    if (data.users.some((item) => item.email === email)) return json(res, 409, { error: 'An account with that email already exists.' });
    const account = { id: randomUUID(), name, email, password: body.password, avatar: name.slice(0, 1).toUpperCase(), savedRecipeIds: [], ratings: {}, joinedAt: new Date().toISOString() };
    data.users.push(account);
    data.sessionUserId = account.id;
    data.mealPlans[account.id] = {};
    data.groceryChecks[account.id] = {};
    writeData(data);
    return json(res, 201, { user: publicUser(account) });
  }

  if (method === 'POST' && pathname === '/api/auth/logout') {
    data.sessionUserId = null;
    writeData(data);
    return json(res, 200, { ok: true });
  }

  if (!user) return json(res, 401, { error: 'Please sign in to use this feature.' });

  if (method === 'POST' && pathname === '/api/recipes') {
    const body = await readBody(req);
    const title = String(body.title || '').trim();
    const ingredients = Array.isArray(body.ingredients) ? body.ingredients.map(normalizeIngredient).filter((item) => item.name) : [];
    if (!title || !ingredients.length || !String(body.instructions || '').trim()) {
      return json(res, 400, { error: 'Add a title, at least one ingredient, and cooking instructions.' });
    }
    const recipe = {
      id: randomUUID(), title, subtitle: String(body.subtitle || 'A recipe shared with the Savorly community.').trim(),
      category: String(body.category || 'Dinner'), image: String(body.image || data.recipes[0].image),
      duration: Number(body.duration) || 30, calories: Number(body.calories) || 450, servings: Number(body.servings) || 2,
      difficulty: String(body.difficulty || 'Easy'), tags: Array.isArray(body.tags) ? body.tags.slice(0, 4) : [],
      ingredients, instructions: String(body.instructions).trim().split('\n').map((line) => line.trim()).filter(Boolean),
      author: user.name, authorId: user.id, rating: 0, ratingCount: 0, createdAt: new Date().toISOString()
    };
    data.recipes.unshift(recipe);
    writeData(data);
    return json(res, 201, { recipe: recipeForClient(recipe, user) });
  }

  if (method === 'POST' && segments.length === 4 && segments[1] === 'recipes' && segments[3] === 'save') {
    const recipe = data.recipes.find((item) => item.id === segments[2]);
    if (!recipe) return json(res, 404, { error: 'Recipe not found.' });
    const saved = user.savedRecipeIds || (user.savedRecipeIds = []);
    const position = saved.indexOf(recipe.id);
    if (position === -1) saved.push(recipe.id); else saved.splice(position, 1);
    writeData(data);
    return json(res, 200, { isSaved: position === -1 });
  }

  if (method === 'POST' && segments.length === 4 && segments[1] === 'recipes' && segments[3] === 'rate') {
    const recipe = data.recipes.find((item) => item.id === segments[2]);
    const body = await readBody(req);
    const value = Math.max(1, Math.min(5, Number(body.rating) || 0));
    if (!recipe || !value) return json(res, 400, { error: 'Select a rating from 1 to 5.' });
    const previous = user.ratings?.[recipe.id];
    user.ratings ||= {};
    if (previous) recipe.rating = Number(((recipe.rating * recipe.ratingCount - previous + value) / recipe.ratingCount).toFixed(1));
    else { recipe.rating = Number(((recipe.rating * recipe.ratingCount + value) / (recipe.ratingCount + 1)).toFixed(1)); recipe.ratingCount += 1; }
    user.ratings[recipe.id] = value;
    writeData(data);
    return json(res, 200, { rating: recipe.rating, ratingCount: recipe.ratingCount, userRating: value });
  }

  if (method === 'PUT' && pathname === '/api/meal-plan') {
    const body = await readBody(req);
    const key = String(body.key || '');
    const recipeId = body.recipeId ? String(body.recipeId) : null;
    if (!/^(mon|tue|wed|thu|fri|sat|sun)-(breakfast|lunch|dinner)$/.test(key)) return json(res, 400, { error: 'Invalid meal slot.' });
    if (recipeId && !data.recipes.some((item) => item.id === recipeId)) return json(res, 404, { error: 'Recipe not found.' });
    data.mealPlans[user.id] ||= {};
    if (recipeId) data.mealPlans[user.id][key] = recipeId; else delete data.mealPlans[user.id][key];
    writeData(data);
    return json(res, 200, { mealPlan: data.mealPlans[user.id], grocery: groceryItems(data, user) });
  }

  if (method === 'POST' && pathname === '/api/grocery/check') {
    const body = await readBody(req);
    data.groceryChecks[user.id] ||= {};
    data.groceryChecks[user.id][String(body.id || '')] = Boolean(body.checked);
    writeData(data);
    return json(res, 200, { grocery: groceryItems(data, user) });
  }

  return json(res, 404, { error: 'Endpoint not found.' });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname.startsWith('/api/')) {
    api(req, res, url.pathname).catch((error) => {
      console.error(error);
      json(res, 500, { error: 'Something went wrong. Please try again.' });
    });
  } else {
    serveFile(res, decodeURIComponent(url.pathname));
  }
});

server.listen(PORT, () => console.log(`Savorly is running at http://localhost:${PORT}`));
