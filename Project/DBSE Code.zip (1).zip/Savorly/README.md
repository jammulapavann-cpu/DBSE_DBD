# Savorly Full-Stack Project

This project includes a complete full-stack setup with:

- Frontend: React.js
- Backend: Node.js + Express.js
- Database: MongoDB support with demo fallback
- Image Storage: Cloudinary support with demo fallback
- API: Nutrition API integration with demo fallback

## Quick start

1. Copy `.env.example` to `.env`
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the app:
   ```bash
   npm run dev
   ```

## Project structure

- `src/` — React frontend
- `server/` — Express backend
- `vite.config.js` — frontend dev server and proxy

## Environment variables

Set your values in `.env`:

```env
PORT=5002
MONGO_URI=mongodb://localhost:27017/savorly
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
NUTRITION_API_ID=your_nutrition_api_id
NUTRITION_API_KEY=your_nutrition_api_key
```

If these are not configured, the app still runs in demo mode with sample data.

## Endpoints

- `GET /api/health`
- `GET /api/recipes`
- `POST /api/recipes`
- `GET /api/nutrition`
- `POST /api/upload`

## Notes

This is a working starter app for a recipe platform and includes the requested stack in code, even when external services are not configured.
